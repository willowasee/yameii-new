# yameii
a discord bot for the be trans throw hands server made using discord.py

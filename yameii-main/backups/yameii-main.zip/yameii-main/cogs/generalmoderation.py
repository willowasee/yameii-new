import discord
from discord.ext import commands
import asyncio

class generalmoderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason=None):
       await member.ban(reason=reason)
       await ctx.send(f'User {member} has been kicked')

    @ban.error
    async def ban_error(self, ctx, error):
     if isinstance(error, commands.MissingPermissions):
        await ctx.send("You cant do that!")

    @commands.command()
    @commands.has_role("sexy beef (mods)")
    async def unban(self, ctx, *, member):
     banned_users = await ctx.guild.bans()
     member_name, member_discriminator = member.split("#")

     for ban_entry in banned_users:
            user = ban_entry.user

            if (user.name, user.discriminator) == (member_name, member_discriminator):
                await ctx.guild.unban(user)
                await ctx.send(f'Unbanned {user.mention}')
                return

    @unban.error
    async def unban_error(self, ctx, error):
     if isinstance(error, commands.MissingPermissions):
        await ctx.send("You cant do that!")
   
    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason=None):
        print(member)
        await member.kick(reason=reason)
        await ctx.send(f'User {member} has been kicked')

    @kick.error
    async def kick_error(self, ctx, error):
     if isinstance(error, commands.MissingPermissions):
        await ctx.send("You cant do that!")
    
    @commands.command(pass_context=True)
    @commands.has_role("sexy beef (mods)")
    async def purge(self, ctx, limit: int):
        y = limit + 1
        await ctx.channel.purge(limit=y)
        await ctx.send('{} messages cleared by {}'.format(limit, ctx.author.mention), delete_after=5)

    @purge.error
    async def purge_error(self, ctx, error):
     if isinstance(error, commands.MissingPermissions):
        await ctx.send("You cant do that!")

def setup(bot):
    bot.add_cog(generalmoderation(bot))

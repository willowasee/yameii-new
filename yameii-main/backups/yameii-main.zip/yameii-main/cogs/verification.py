import discord
from discord.ext import commands, tasks
import asyncio
import sqlite3

con = sqlite3.connect('/root/yameii/discord.db')
c = con.cursor()

class verification(commands.Cog):
 
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message):
     if message.content == '.stopvent':
       pass
     else:
      if message.content == '.startvent':
        pass
      else: 
        if isinstance(message.channel, discord.channel.DMChannel):
         c.execute("select venting from users where id = ?", (message.author.id,))
         v = c.fetchone()[0]
         if v == 1:
           c.execute("SELECT aid FROM users WHERE id = {}".format(message.author.id,))
           aid = c.fetchone()[0]
           if aid == "blacklisted":
            pass
           else:
             channel = self.bot.get_channel(850964001952366622)
             em = discord.Embed(title = "anon vent", description = "{}".format(message.content))
             em.set_footer(text = "{}".format(aid))
             await channel.send(embed = em)
 
    @commands.command()
    async def startvent(self, ctx):
        c.execute("update users set venting = '1' where id = ?", (ctx.message.author.id,))
        c.connection.commit()
        await ctx.send("anon venting **on** all messages you send will now be proxied")

    @commands.command()
    async def stopvent(self, ctx):
        c.execute("update users set venting = '0' where id = ?", (ctx.message.author.id,))
        c.connection.commit()
        await ctx.send("anon venting **off**")

    @commands.command()
    async def start(self, ctx):
       c.execute("select verif from users where id = ?", (ctx.message.author.id,))
       check1 = c.fetchone()[0]
       if check1 != 'verified':
        member = ctx.message.author
        channel = ctx.message.guild.system_channel
        x = '''Please answer the following questions in one message;
           
            Have you read the rules, if so what is your *least* fav rule and why?
            Why do you want to join Be Trans Throw Hands?
            How did you find this server?
            What is your age, are you trans or cis? If you don't want to disclose this please tell us why via modmail- use `.modmail "message goes here"` in a dm with me, please note the quotation marks in the command are required.

            Please make sure you fill out the questions **in one message!**'''
        em = discord.Embed(title = "welcome to be trans throw hands", description = "{}".format(x))
        await channel.send("<@{}>".format(ctx.message.author.id), embed = em)
        
        def check(m):
             return m.author == ctx.author and m.channel == ctx.channel

        msg = await self.bot.wait_for("message", check = check)
        await ctx.send(f"thank you, <@{ctx.author.id}> your response has been sent to the mods who will look over it asap!")
        channel = self.bot.get_channel(855345854914887692)
        em = discord.Embed(title = "verify new user?", description = '''The user said,
         **{.content}**'''.format(msg))
        em.set_footer(text = "{.author} React with ✅ to verify and ❌ to kick".format(msg))
        message = await channel.send(embed = em)
        c.execute("update users set verif = ? where id = ?", (message.id, ctx.author.id))
        c.connection.commit()
        await message.add_reaction('✅')
        await message.add_reaction('❌')

        
    @commands.Cog.listener()
    async def on_reaction_add(self, reaction, user):
         if user.id != 855103658773839892:
          c.execute("select id from users where verif = ?", (reaction.message.id,))
          v = c.fetchone()[0]
          if v is not None:
           if str(reaction.emoji) == '✅':
                  member = reaction.message.guild.get_member(v)
                  channel = self.bot.get_channel(855345854914887692)
                  await channel.send("<@{}> was verified".format(v))
                  c.execute("update users set verif = 'verified' where id = ?", (v,))
                  c.connection.commit()
                  var = discord.utils.get(reaction.message.guild.roles, name = 'unverified')
                  await member.remove_roles(var)
                  var = discord.utils.get(reaction.message.guild.roles, name = 'member')
                  await member.add_roles(var)
                  channel = self.bot.get_channel(850961814987472897)
                  await channel.send(f'welcome <@{v}>! check out <#851144414684381194> also fill out a pronoun chart in <#851136868175314954> and introduce yourself in <#851203511991271485> if you’d like!')

           else: 
            if str(reaction.emoji) == '❌':
             channel = self.bot.get_channel(855345854914887692)
             member = reaction.message.guild.get_member(v)
             await channel.send("<@{}> was verified".format(v))
             await member.kick(reason='did not pass verification')
             

def setup(bot):
    bot.add_cog(verification(bot))


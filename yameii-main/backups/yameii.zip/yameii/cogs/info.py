import discord
from discord.ext import commands
import asyncio
import inspirobot
import random

class info(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    
    @commands.group(invoke_without_command=True)
    async def info(self, ctx):
        em = discord.Embed(title = "info", description = "use .info <command> for extended information on that command", color = ctx.author.color)
        em.add_field(name = "info", value = "`info`,`ping`")
        em.add_field(name = "moderation", value = "`purge`,`kick`,`ban`,`lookup`,`blacklist`")
        em.add_field(name = "pronoun system", value = "`setpronoun`,`removepronoun`,`pronounlist`")
        em.add_field(name = "dm only", value = "`vent`,`modmail`,`startvent`,`stopvent`")
        em.add_field(name = "misc", value = "`inspire`,`start`,`roulette`")
        await ctx.send(embed = em) 
    
    @info.command()
    async def roulette(self, ctx):
        em = discord.Embed(title = "roulette", description = "russian roulette, has a 1% chance of kicking you from the server", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".roulette")
        await ctx.send(embed = em)


    @info.command()
    async def startvent(self, ctx):
        em = discord.Embed(title = "startvent", description = "vent anonmusly, similar to `.vent`, but proxies all following messages dm'ed to me into the vent channel", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".startvent")
        await ctx.send(embed = em)

    @info.command()
    async def stopvent(self, ctx):
        em = discord.Embed(title = "stopvent", description = "stops messages from being proxied", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".stopvent")
        await ctx.send(embed = em)

    @info.command()
    async def ping(self, ctx):
        em = discord.Embed(title = "ping", description = "returns the bots latency", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".ping")
        await ctx.send(embed = em)

    @info.command()
    async def purge(self, ctx):
        em = discord.Embed(title = "purge", description = "deletes messages, if no ammount is specified it defaults to 10", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".purge [ammount]")
        await ctx.send(embed = em)
    
    @info.command()
    async def kick(self, ctx):
        em = discord.Embed(title = "kick", description = "kicks a user with an optional reason", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".kick <user> [reason]")
        await ctx.send(embed = em)
    
    @info.command()
    async def ban(self, ctx):
        em = discord.Embed(title = "ban", description = "bans a user with an optional reason", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".ban <user> [reason]")
        await ctx.send(embed = em)

    @info.command()
    async def lookup(self, ctx):
        em = discord.Embed(title = "lookup", description = "n/a", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".lookup <user>")
        await ctx.send(embed = em)
    
    @info.command()
    async def inspire(self, ctx):
        em = discord.Embed(title = "inspire", description = "sends an inspirational quote", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".inspire")
        await ctx.send(embed = em)

    @info.command()
    async def blacklist(self, ctx):
        em = discord.Embed(title = "blacklist", description = "blacklist a user from using anon vent", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".blacklist <aid>")
        await ctx.send(embed = em)

    @info.command()
    async def vent(self, ctx):
        em = discord.Embed(title = "vent", description = "vent anonmusly, you *must* send your vent in quotation marks and this only works in a direct message with me", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".vent <vent>")
        await ctx.send(embed = em)


    @info.command()
    async def modmail(self, ctx):
        em = discord.Embed(title = "modmail", description = "contact staff, you *must* send your message in quotation marks and this only works in a direct message with me", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".modmail <msg>")
        await ctx.send(embed = em)

    @info.command()
    async def setpronoun(self, ctx):
        em = discord.Embed(title = "setpronoun", description = "set a pronoun, please note pronous that contain spaces need to go inside quotation marks!", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".setpronoun <pronouns>")
        await ctx.send(embed = em)

    @info.command()
    async def removepronoun(self, ctx):
        em = discord.Embed(title = "removepronoun", description = "remove a pronoun, please note pronouns containing spaces need to go inside quotaion marks!", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".removepronoun <pronouns>")
        await ctx.send(embed = em)

    @info.command()
    async def pronounlist(self, ctx):
        em = discord.Embed(title = "pronounlist", description = "lists the current pronoun list, if the list is under 25 new pronouns can still be created using `.setpronoun`", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".pronounlist")
        await ctx.send(embed = em)

    @info.command()
    async def start(self, ctx):
        em = discord.Embed(title = "start", description = "used when first joining for verification", color = ctx.author.color)
        em.add_field(name = "**syntax**", value = ".start")
        await ctx.send(embed = em)


def setup(bot):
    bot.add_cog(info(bot))

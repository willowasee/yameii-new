import discord
from discord.ext import commands
from discord.utils import get
import sqlite3
import random
import string
import re

con = sqlite3.connect('/root/yameii/discord.db')
c = con.cursor()

class userdatabaseinteractions(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message):
        c.execute("SELECT id FROM users")
        rows = c.fetchall()
        if (message.author.id,) in rows:
           pass
        else:
            letters = string.ascii_lowercase
            result = ''.join(random.choice(letters) for i in range(4))
            data = (message.author.id, result)
            sql = ''' INSERT INTO users(id,aid)
              VALUES(?,?) '''
            c.execute(sql, data)
            c.connection.commit()

    @commands.command()
    async def vent(self, ctx, vent: str):
     if isinstance(ctx.channel, discord.channel.DMChannel):
           c.execute("SELECT aid FROM users WHERE id = {}".format(ctx.author.id))
           aid = c.fetchone()[0]
           if aid == "blacklisted":
               await ctx.send("**You are blacklisted**")
           else:
             channel = self.bot.get_channel(850964001952366622)
             em = discord.Embed(title = "anon vent", description = "{}".format(vent))
             em.set_footer(text = "{}".format(aid))
             await channel.send(embed = em)

    @commands.command()
    @commands.has_role("sexy beef (mods)")
    async def lookup(self, ctx, aid: str):
     c.execute("SELECT id FROM users WHERE aid = '{}'".format(aid))
     v = c.fetchone()[0]
     await ctx.send("The AID `{}` belongs to <@{}>".format(aid, v))

    @lookup.error
    async def lookup_error(self, ctx, error):
     if isinstance(error, commands.MissingPermissions):
        await ctx.send("You cant do that!")

    @commands.command()
    @commands.has_role("sexy booster")
    async def aidreset(self, ctx):
     c.execute("SELECT id FROM users")
     rows = c.fetchall()
     for row in rows:
        letters = string.ascii_lowercase
        result = ''.join(random.choice(letters) for i in range(4))
        c.execute('''UPDATE users SET aid = ? WHERE id = ?''', (result, row[0]))
        c.connection.commit()
     await ctx.send("All AID's have been randomized!")

    @aidreset.error
    async def aidreset_error(self, ctx, error):
     if isinstance(error, commands.MissingPermissions):
        await ctx.send("You cant do that!")

    @commands.command()
    @commands.has_role("sexy booster")
    async def database(self, ctx, sql: str, save: str):
     em = discord.Embed(title = "database interaction", description = "database interactions are not saved by default", color = ctx.author.color)
     if save == 'yes':
         c.execute(sql)
         c.connection.commit()
         rows = c.fetchall()
         em.add_field(name = "result", value = "command executed sucsessfuly")
     else:
         c.execute(sql)
         rows = c.fetchall()
         em.add_field(name = "result", value = "{}".format(rows))
     await ctx.send(embed = em)

    @database.error
    async def database_error(self, ctx, error):
     if isinstance(error, commands.MissingPermissions):
        await ctx.send("You cant do that!")

    @commands.command()
    @commands.has_role("sexy beef (mods)")
    async def blacklist(self, ctx, aid: str):
     c.execute("SELECT id FROM users WHERE aid = '{}'".format(aid,))
     v = c.fetchone()[0]
     c.execute('''UPDATE users SET aid = 'blacklisted' WHERE id = ?''', (v,))
     c.connection.commit()
     await ctx.send("The AID `{}` belongs to <@{}> and they have been blacklisted!".format(aid, v))

    @blacklist.error
    async def blacklist_error(self, ctx, error):
     if isinstance(error, commands.MissingPermissions):
        await ctx.send("You cant do that!")

    @commands.command()
    async def setpronoun(self, ctx, pronouns: str):
        c.execute("SELECT pronoun FROM pronouns where pronoun = ?", (pronouns,))
        rows = c.fetchone()
        if rows is not None:
            c.execute("SELECT users FROM pronouns where pronoun = ?", (pronouns,))
            v = c.fetchone()[0]
            users = v + 1
            member = ctx.message.author
            var = discord.utils.get(ctx.message.guild.roles, name = f'{pronouns}')
            await member.add_roles(var)
            await ctx.send(f'<@{ctx.message.author.id}> gave you **{pronouns}**')
            c.execute("UPDATE pronouns SET users = ? where pronoun = ?", (users,pronouns))
            c.connection.commit()
        else:
            c.execute("SELECT pronoun FROM pronouns")
            rows = c.fetchall()
            v = 0
            for row in rows:
                v = v + 1
            print(v)
            if v == 25:
                await ctx.send(f'<@{ctx.message.author.id}> the server pronoun limit has been reached! please use `.pronounlist` and select some from the list!')
            else:
                sql = ''' INSERT INTO pronouns(pronoun,users)
                VALUES(?,?) '''
                users = 1
                data = (pronouns, users)
                c.execute(sql, data)
                c.connection.commit()
                guild = ctx.guild
                member = ctx.message.author
                await guild.create_role(name=f'{pronouns}')
                var = discord.utils.get(ctx.message.guild.roles, name = f'{pronouns}')
                await member.add_roles(var)
                await ctx.send(f'<@{ctx.message.author.id}> gave you **{pronouns}**')

    @commands.command()
    async def removepronoun(self, ctx, pronouns: str):
        c.execute("SELECT pronoun FROM pronouns where pronoun = ?", (pronouns,))
        rows = c.fetchone()
        if rows is not None:
            c.execute("SELECT users FROM pronouns where pronoun = ?", (pronouns,))
            v = c.fetchone()[0]
            users = v - 1
            if users == 0:
             member = ctx.message.author
             var = discord.utils.get(ctx.message.guild.roles, name = f'{pronouns}')
             await var.delete()
             c.execute('''DELETE FROM pronouns WHERE pronoun = ?''', (pronouns,))
             await ctx.send(f'<@{ctx.message.author.id}> removed **{pronouns}**')
             c.connection.commit()
            else: 
                c.execute('''UPDATE pronouns SET users = ? where pronoun = ?''', (users,pronouns))
                member = ctx.message.author
                var = discord.utils.get(ctx.message.guild.roles, name = f'{pronouns}')
                await member.remove_roles(var)
                await ctx.send(f'<@{ctx.message.author.id}> removed **{pronouns}**')
                c.connection.commit()

    @commands.command()
    async def pronounlist(self, ctx):
        c.execute("SELECT pronoun FROM pronouns")
        rows = c.fetchall()
        v = []
        for row in rows:
         v.append(row[0])
        v1 = "/n".join(v)
        em = discord.Embed(title = "select an existing pronoun or create your own with `.setpronoun`", description = f"{v1}", color = ctx.author.color)
        await ctx.send(embed = em)

def setup(bot):
    bot.add_cog(userdatabaseinteractions(bot))

import discord
from discord.ext import commands
import asyncio
import inspirobot
import random
import os
import requests as req

class misc(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command()
    async def roulette(self, ctx):
     letters = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9',]
     result = ''.join(random.choice(letters) for i in range(2))
     if result == '69':
      v = ctx.message.author.id
      member = ctx.message.guild.get_member(v)
      await ctx.send("**you died**")
      await member.kick(reason='russian roulette')
     else:
       await ctx.send("you're safe, *for now.*")

   
    @commands.command()
    async def modmail(self, ctx, vent: str):
     if isinstance(ctx.channel, discord.channel.DMChannel):
         channel = self.bot.get_channel(851235532078972938)
         em = discord.Embed(title = "modmail", description = "{}".format(vent))
         em.set_footer(text = "{}".format(ctx.message.author))
         await channel.send(embed = em)
   
    @commands.command()
    @commands.has_role("sexy beef (mods)")
    async def announce(self, ctx, vent: str):
         channel = self.bot.get_channel(851137076404551680)
         em = discord.Embed(title = "announement", description = "{}".format(vent))
         em.set_footer(text = "from {}".format(ctx.message.author))
         await channel.send(embed = em)
    
    @commands.command()
    @commands.bot_has_permissions(embed_links=True)
    async def inspire(self, ctx: commands.Context):
        inspiration = await asyncio.get_running_loop().run_in_executor(None, inspirobot.generate)
        embed = discord.Embed(url=inspiration.url,
                              title = f"Inspiration for {ctx.author.display_name}",
                              color = ctx.author.color)
        embed.set_image(url=inspiration.url)
        await ctx.send(embed=embed)

    
    @commands.command()
    async def ping(self, ctx):
        await ctx.send('pong! `{0}ms`'.format(round(self.bot.latency, 1)))

def setup(bot):
    bot.add_cog(misc(bot))


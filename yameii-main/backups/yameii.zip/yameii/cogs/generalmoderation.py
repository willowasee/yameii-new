import discord
from discord.ext import commands
import asyncio
import sqlite3

con = sqlite3.connect('/root/yameii/discord.db')
c = con.cursor()

class generalmoderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason=None):
       await member.ban(reason=reason)
       await ctx.send(f'User {member} has been banned')
       c.execute('''UPDATE users SET verif = 'banned' WHERE id = ?''', (member,))
       c.connection.commit()

    @ban.error
    async def ban_error(self, ctx, error):
     if isinstance(error, commands.MissingPermissions):
        await ctx.send("You cant do that!")
   
    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason=None):
        print(member)
        await member.kick(reason=reason)
        c.execute('''UPDATE users SET verif = 'kicked' WHERE id = ?''', (member,))
        c.connection.commit()
        await ctx.send(f'User {member} has been kicked')

    @kick.error
    async def kick_error(self, ctx, error):
     if isinstance(error, commands.MissingPermissions):
        await ctx.send("You cant do that!")
    
    @commands.command(pass_context=True)
    @commands.has_role("sexy beef (mods)")
    async def purge(self, ctx, limit=10):
        y = limit + 1
        await ctx.channel.purge(limit=y)
        await ctx.send('{} messages cleared by {}'.format(limit, ctx.author.mention), delete_after=5)

    @purge.error
    async def purge_error(self, ctx, error):
     if isinstance(error, commands.MissingPermissions):
        await ctx.send("You cant do that!")

def setup(bot):
    bot.add_cog(generalmoderation(bot))
